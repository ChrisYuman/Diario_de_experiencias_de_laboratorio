﻿public class Circulo
{
    private double Radio;
   

    public Circulo(double radio)
    {
        Radio = radio;
    }

    private double ObtenerPerimetro()
    {
        double perimetro = 0;
        perimetro = 2 * Radio * 3.1416;
        return perimetro;
    }
    private double ObtenerArea()
    {
        double area = 0;
        area = 3.1416 * Math.Pow(Radio, 2); 
        return area;
    }
    private double ObtenerVolumen()
    {
        double volumen = 0;
        volumen = (4 * 3.1416 * Math.Pow(Radio, 3) / 3); 
        return volumen;
    }
    public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
    {
        unPerimetro = ObtenerPerimetro();
        unArea = ObtenerArea();
        unVolumen = ObtenerVolumen();
    }

    public void MostrarLibro()
    {
        

    }

    static void Main()
    {
        double perimetro = 0;
        double area = 0;
        double volumen = 0;

        Console.WriteLine("Ingrese el radio");
        double radio = Convert.ToDouble(Console.ReadLine());
        Circulo objCirculo = new Circulo(radio);

        objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);


        Console.WriteLine("El perimetro es "+ perimetro);
        Console.WriteLine("El area es " + area);
        Console.WriteLine("El volumen es " + volumen);


        Console.ReadKey();
    }

}
﻿using System;

class Program
{
    static void Main()
    {
        
        int i = 1;
        int contprimos = 0;
        double residuo = 0;

        while (contprimos < 10)
        {
            if (i == 2)
            {
                Console.WriteLine(i);
                contprimos++;
            }
            else { 
            residuo = i % 2;
            if (residuo > 0)
            {
                    if (i == 3)
                    {
                        Console.WriteLine(i);
                        contprimos++;
                    }
                    else { 
                        residuo = i % 3;
                        if (residuo > 0)
                {
                            if (i == 5)
                            {
                                Console.WriteLine(i);
                                contprimos++;
                            }
                            else
                            {
                                residuo = i % 5;
                                if (residuo > 0)
                                {
                                    if (i == 7)
                                    {
                                        Console.WriteLine(i);
                                        contprimos++;
                                    }
                                    else 
                                    { 
                                    residuo = i % 7;
                                    if (residuo > 0)
                                    {
                                        if (i == 11)
                                            {
                                                Console.WriteLine(i);
                                                contprimos++;
                                            }
                                            else
                                            {
                                                residuo = i % 11;
                                                if (residuo > 0)
                                                {
                                                    Console.WriteLine(i);
                                                    contprimos++;
                                                }
                                            }
                                        
                                    }
                                    }
                                }
                            }
                        }
                    }
            
            }
            }
            i++;
        }
        
        Console.ReadLine();
    }
}
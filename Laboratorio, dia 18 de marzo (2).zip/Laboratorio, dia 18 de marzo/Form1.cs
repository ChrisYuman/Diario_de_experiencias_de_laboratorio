﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratorio__dia_18_de_marzo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Automovil myAutomovil = new Automovil();

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            myAutomovil.DefinirModelo(Convert.ToInt32(txtMonto.Text));
           
            myAutomovil.DefinirPrecio(Convert.ToDouble(txtPrecio.Text));
           
            myAutomovil.DefinirMarca(txtMarca.Text);
         
            myAutomovil.DefinirTipodeCambio(Convert.ToDouble(txtCambio.Text));
          

            MessageBox.Show("Los datos fueron guardados correctamente");

            txtResultado.Text = myAutomovil.MostrarInformacion();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtDescuento.Clear();
            txtMarca.Clear();
            txtMonto.Clear();
            txtPrecio.Clear();
            txtResultado.Clear();

        }

        

        private void btnAplicar_Click(object sender, EventArgs e)
        {
            myAutomovil.AplicarDescuento(Convert.ToDouble(txtDescuento.Text));
            txtResultado.Text = myAutomovil.MostrarInformacion();
        }

        private void btnCambiar_Click(object sender, EventArgs e)
        {
            myAutomovil.CambiarDisponibilidad();
            txtResultado.Text = myAutomovil.MostrarInformacion();
        }
    }
}

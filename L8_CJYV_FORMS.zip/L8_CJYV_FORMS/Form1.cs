﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_CJYV_FORMS
{
    public partial class Sumatoria : Form
    {
        public Sumatoria()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            tabControl1.Visible = true;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("Seleccionaste la pestaña de sumatoria");
                    tabControl1.SelectedTab = tabPage1;
                    textBox1.Focus();
                    break;
                case 1:
                    MessageBox.Show("Seleccionaste la pestaña de tablas de multiplicar");
                    tabControl1.SelectedTab = tabPage2;
                    textBox2.Focus();
                    break;
                case 2:
                    MessageBox.Show("Seleccionaste la pestaña de numeros perfectos");
                    tabControl1.SelectedTab = tabPage3;
                    textBox3.Focus();
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0 ) { 
            int numero = int.Parse(textBox1.Text);
            int i = 1;
            int suma = 0;

            if (numero > 0)
            {
                do
                {
                    suma = suma + i;

                    i++;


                }
                while (i <= numero);
                
            }
            else
            {
                MessageBox.Show("El numero debe ser mayor a 0");
            }
            label8.Text = suma.ToString();
        }else if (comboBox1.SelectedIndex == 1)
            {
                int numero1 = int.Parse(textBox2.Text);
                int i = 0;

                for (i = 1; i <= numero1; i++)
                {
                    int resultado = i * numero1;
                    listbox1.Items.Add(i + " * " + numero1 + " = " + resultado);
                }



                
            }else if(comboBox1.SelectedIndex == 2 )
            {
                int numero3 = int.Parse(textBox3.Text);
                
                

                int suma2 = 0;
               
                    if (numero3 > 0)
                    {
                        for (int a = 1; a < numero3; a++)
                        {
                            if (numero3 % a == 0)
                            {
                                suma2 = suma2 + a;

                            }
                        }
                        if (suma2 == numero3)
                        {
                        label10.Text = (numero3 + " Es un numero perfecto");
                        }
                        else
                        {
                        label10.Text = (numero3 +" No es un numero perfecto");
                        }
                    }
                    else
                    {
                    label10.Text = (numero3 + " Ingrese un numero mayor a 0");
                    }
                }
            }
    }
    }


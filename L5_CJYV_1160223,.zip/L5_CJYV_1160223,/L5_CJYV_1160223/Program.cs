﻿class Program
{
    static void Main(string[] args)
    {
        int numero1 = 0;
        goto ejercicio2;

        Console.WriteLine("Ejercicio 1:");
        Console.WriteLine("Ingrese un numero entero: ");
        
        bool canConvert = int.TryParse(Console.ReadLine(), out numero1);
        if (canConvert == true)
        {
            if (numero1 > 0)
            {

                Console.WriteLine("El numero es positivo ");

            }
            else if (numero1 < 0)
            {
                Console.WriteLine("El numero es negativo " );
            }
            else
            {

                Console.WriteLine("El numero es igual a cero");

            }
        }else{
            Console.WriteLine("Usted ingreso una letra");
        }
        Console.ReadKey();
    ejercicio2:
        Console.WriteLine("Ejercicio 2:");
        Console.WriteLine("Ingrese un numero del 1 al 7");
        int dia = Convert.ToInt32(Console.ReadLine());
        switch (dia)
        {
            case 1:
                Console.WriteLine("Dia: Lunes");
                break;
            case 2:
                Console.WriteLine("Dia: Martes");
                break;
            case 3:
                Console.WriteLine("Dia: Miercoles");
                break;
            case 4:
                Console.WriteLine("Dia: Jueves");
                break;
            case 5:
                Console.WriteLine("Dia: Viernes");
                break;
            case 6:
                Console.WriteLine("Dia: Sabado");
                break;
            case 7:
                Console.WriteLine("Dia : Domingo");
                break;
            default:
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                break;
                Console.ReadKey();
    }
    }
}

